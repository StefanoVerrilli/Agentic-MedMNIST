# HAT-MedMNIST: sequential hybrid agents on PathMNIST

This repository is a reproducible MVP of the HAT-MedMNIST proposal. It uses
small, role-specialised agents to train a deliberately tiny CNN on **PathMNIST**;
the contribution is the orchestration, typed hand-offs, provenance and review
gates, not a clinical classifier.

PathMNIST is a nine-class, three-channel histology benchmark. The official
MedMNIST split is train 89,996 / validation 10,004 / test 7,180; the test set
comes from a different clinical centre. The pipeline preserves these splits and
never creates validation data by randomly splitting the training set.

## Architecture

```mermaid
flowchart TD
    O[Orchestrator: sequential state machine]
    O --> I[Ingestion]
    O --> P[Profiling / ambiguity]
    O --> R[Representation]
    O --> E[Experiment design]
    O --> T[Training]
    O --> V[Evaluation]
    O --> A[Abstention / OOD proxy]
    O --> Q[Reporting]
    B[(Blackboard: typed immutable artefacts + JSONL log)]
    W[Reviewer: audit after every stage, retry or veto]
    I & P & R & E & T & V & A & Q <--> B
    W -.-> O
```

Agents do not call one another. They communicate through Pydantic contracts in
`contracts.py`. A Blackboard write creates an immutable, numbered JSON envelope
with a SHA-256 checksum; every stage, decision, retry and gate is appended to
`decision_log.jsonl`.

## Ollama and the one-call-at-a-time rule

Only four decision types use model reasoning: ambiguity, representation,
experiment configuration and review comments. The rest is deterministic. The
shared `OllamaReasoner` calls Ollama's native `/api/chat` endpoint with a JSON
Schema, temperature 0 and a global lock. Consequently, agents and retries are
always executed sequentially and at most one Ollama request is active in the
process. Invalid output is rejected by the schema and replaced with a validated
heuristic; use `--require-llm` to make such a failure fatal.

```bash
python -m pip install -r requirements.txt
ollama pull qwen2.5:7b

# Fast, stratified demonstration (6000/1200/1800 samples)
python run.py --quick \
  --ollama-base http://localhost:11434 \
  --ollama-model qwen2.5:7b

# Offline and reproducible heuristic decisions
python run.py --quick --offline

# Full official splits, three seeds and the three representation ablations
python run.py --seeds 42,43,44 --ablation-suite \
  --ollama-base http://localhost:11434 \
  --ollama-model qwen2.5:7b
```

The dataset is downloaded by MedMNIST into its normal cache. Use
`--data-root PATH` to choose another cache and `--no-download` to require an
already-present archive. CPU is the default device; `--device cuda` is
available when deterministic CUDA operations are supported.

## What is measured

- profiling covers every loaded sample and records class counts, channel
  statistics, blank-image and duplicate checks, the official archive MD5 and
  selected-index fingerprints;
- preprocessing computes normalization statistics on **train only**, applies
  augmentation only to train, and records the official split manifest;
- training is seeded, uses a deterministic DataLoader, writes a checksumed
  best checkpoint and keeps the configuration bounded (`lr`, epochs, hidden
  width and batch size);
- evaluation reports accuracy, balanced accuracy, macro/per-class precision,
  recall, F1, one-vs-rest ROC-AUC (when defined) and a confusion matrix;
- abstention calibrates a max-softmax threshold on validation, reports covered
  accuracy/selective risk on test, and evaluates a clearly labelled controlled
  Gaussian-corruption OOD proxy (not a clinical OOD claim);
- the conventional baseline uses the exact same selected split and seed; the
  optional ablation suite runs three representation scenarios;
- `--seeds 42,43,44` produces a mean and population standard deviation for
  repeated-run variance.

## Outputs

Each invocation creates a new directory under `runs/pathmnist_<timestamp>/`:

```text
seed_42/
  artefacts/                  # immutable 0001_name_v001.json files
  blobs/                      # checkpoints
  decision_log.jsonl          # stage, LLM, retry and gate provenance
  dossier.json                # final latest-artifact view
experiment_summary.json      # seed comparison and variance
```

## Tests

The tests do not download data or require Torch. They cover contract bounds,
Ollama JSON-schema validation and fallback, global request serialization,
official split preservation, retry/veto behaviour, multiclass metrics and ten
fault-injection cases (the reviewer must detect at least 90%).

```bash
python -m unittest discover -s tests -v
```

## Files

| File | Responsibility |
| --- | --- |
| `contracts.py` | Pydantic contracts, immutable Blackboard and decision log |
| `llm.py` | provider-neutral seam with sequential Ollama implementation |
| `ml.py` | PathMNIST loading, deterministic data, training and metrics primitives |
| `agents.py` | ingestion, profiling, representation, design, training, evaluation, abstention, reporting and reviewer |
| `orchestrator.py` | sequential stage gates, bounded retries and veto handling |
| `baseline.py` | conventional baseline and representation ablations |
| `run.py` | CLI, repeated seeds and experiment summary |
| `tests/` | contract, integration-with-fakes and fault-injection tests |

This is a non-clinical research/engineering demonstrator; it makes no
diagnostic or patient-facing claim.
