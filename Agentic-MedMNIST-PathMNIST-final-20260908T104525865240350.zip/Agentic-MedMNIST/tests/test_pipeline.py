from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from agents import (
    IngestionAgent,
    PreprocessingAgent,
    ProfilingAmbiguityAgent,
    ReportingAgent,
    ReviewerConsistencyAgent,
)
from contracts import AnomalyReport, Blackboard, RunManifest
from llm import OllamaReasoner
from ml import evaluate_probabilities, stratified_indices
from orchestrator import Orchestrator
from tests.helpers import make_bundle


class PipelineTests(unittest.TestCase):
    def test_official_validation_split_is_preserved(self) -> None:
        bundle = make_bundle()

        def loader(**kwargs):
            return bundle

        with tempfile.TemporaryDirectory() as directory:
            bb = Blackboard(directory)
            reasoner = OllamaReasoner(base_url=None)
            IngestionAgent(loader=loader).run(bb)
            ProfilingAmbiguityAgent(reasoner).run(bb)
            PreprocessingAgent(reasoner).run(bb)
            split = bb.get("split_manifest")
            prepared = bb.get_blob("prepared_data")
            self.assertEqual(split.strategy, "official")
            self.assertEqual(split.train_size, 27)
            self.assertEqual(split.val_size, 18)
            self.assertEqual(split.test_size, 18)
            self.assertIs(prepared.bundle.images["val"], bundle.images["val"])
            findings = ReviewerConsistencyAgent(reasoner)._deterministic_findings(
                bb, "preprocessing"
            )
            self.assertEqual(findings, [])

    def test_stratified_subsample_is_reproducible_and_covers_all_classes(self) -> None:
        labels = np.repeat(np.arange(9), np.arange(1, 10) + 4)
        first = stratified_indices(labels, 27, 123)
        second = stratified_indices(labels, 27, 123)
        self.assertTrue(np.array_equal(first, second))
        self.assertEqual(set(labels[first].tolist()), set(range(9)))

    def test_multiclass_evaluation_has_all_required_metrics(self) -> None:
        targets = np.repeat(np.arange(9), 2)
        probabilities = np.eye(9)[targets]
        report = evaluate_probabilities(
            probabilities, targets, make_bundle().labels
        )
        self.assertEqual(report.accuracy, 1.0)
        self.assertEqual(report.macro_f1, 1.0)
        self.assertEqual(report.roc_auc_ovr_macro, 1.0)
        self.assertEqual(sum(sum(row) for row in report.confusion_matrix), 18)

    def test_final_dossier_contains_reporting_review(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            bb = Blackboard(directory)
            bb.put(
                "run_manifest",
                RunManifest(
                    run_id="test",
                    dataset="pathmnist",
                    seed=42,
                    created_at="2026-01-01T00:00:00+00:00",
                    python_version="3.12",
                    platform="test",
                    package_versions={},
                    llm_mode="heuristic",
                    llm_model="none",
                ),
                producer="test",
            )
            reasoner = OllamaReasoner(base_url=None)
            orchestrator = Orchestrator(
                [ReportingAgent()],
                ReviewerConsistencyAgent(reasoner),
                max_stage_retries=0,
            )
            orchestrator.run(bb)
            dossier = json.loads(
                (Path(directory) / "dossier.json").read_text(encoding="utf-8")
            )
            self.assertIn("anomaly_reporting", dossier["latest_artefacts"])
            self.assertEqual(dossier["status"], "completed")

    def test_orchestrator_retries_then_promotes(self) -> None:
        calls: list[str] = []

        class Dummy:
            name = "dummy"

            def run(self, bb):
                calls.append("run")

        class Reviewer:
            count = 0

            def review(self, bb, stage, *, attempt=1):
                self.count += 1
                warning = self.count == 1
                return AnomalyReport(
                    stage=stage,
                    attempt=attempt,
                    severity="warning" if warning else "ok",
                    action="revise" if warning else "continue",
                    comment="retry" if warning else "pass",
                    source="test",
                )

        with tempfile.TemporaryDirectory() as directory:
            orchestrator = Orchestrator([Dummy()], Reviewer(), max_stage_retries=1)
            orchestrator.run(Blackboard(directory))
            self.assertEqual(calls, ["run", "run"])
            self.assertEqual(orchestrator.status, "completed")


if __name__ == "__main__":
    unittest.main()
